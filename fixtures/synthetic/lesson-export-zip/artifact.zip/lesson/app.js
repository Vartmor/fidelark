const result = document.getElementById("result");
for (const button of document.querySelectorAll("[data-answer]")) {
  button.addEventListener("click", () => {
    result.textContent = button.dataset.answer === "right" ? "Correct!" : "Not quite.";
  });
}
const light = document.getElementById("light");
light.addEventListener("input", () => {
  document.getElementById("rate").value = light.value;
});
