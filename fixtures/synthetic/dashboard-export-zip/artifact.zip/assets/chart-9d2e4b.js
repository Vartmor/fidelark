export function drawChart(canvas, rows) {
  const ctx = canvas.getContext("2d");
  const max = Math.max(...rows.map((r) => r.total));
  rows.forEach((r, i) => {
    const h = (r.total / max) * canvas.height;
    ctx.fillRect(i * 40 + 10, canvas.height - h, 30, h);
  });
}
