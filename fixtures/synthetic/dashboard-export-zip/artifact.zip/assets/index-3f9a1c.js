import { drawChart } from "./chart-9d2e4b.js";
const root = document.getElementById("root");
const region = localStorage.getItem("region") ?? "all";
const response = await fetch("https://api.example.com/v1/sales?quarter=3&region=" + region);
const rows = await response.json();
root.innerHTML = '<div class="logo"></div><canvas width="640" height="320"></canvas>';
drawChart(root.querySelector("canvas"), rows);
