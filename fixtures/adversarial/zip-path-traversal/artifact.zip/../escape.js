console.log('written outside the folder');
