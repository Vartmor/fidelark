rem runs at login
